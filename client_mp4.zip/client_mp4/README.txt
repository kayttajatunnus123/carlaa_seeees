This docker image saves the video output to an mp4 file.

To build, run e.g.
docker build -t carla_client_mp4 .

Run with etc.
docker run --name carla_client_mp4 --mount \
    source=carla_mp4_output,target=/app/output carla_client_mp4