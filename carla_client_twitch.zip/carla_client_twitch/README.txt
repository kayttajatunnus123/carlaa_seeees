This docker image streams live stream to twitch. The stream can be found here:
https://www.twitch.tv/g11os2018

The video might be a bit laggy. This is mainly due to the variable frame rate of
the server and probably not enough buffering. One also has to wait some 10+
seconds before the stream goes live in twitch.

To build, run e.g.
docker build -t carla_client_twitch .
